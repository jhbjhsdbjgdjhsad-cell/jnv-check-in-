// JNV Check-in: shared database in Google Sheets.
// 1) Change the PIN below. 2) Deploy as a Web app (Execute as: Me, Access: Anyone).
const PIN = "CHANGE-THIS-PIN";
const TZ = "Asia/Kolkata";
const SHEETS = {
  Students: ["id", "name", "roll", "house"],
  Logs: ["id", "ts", "sid", "kind", "detail", "date", "time", "name", "roll", "house"]
};

function sheet_(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange("A:Z").setNumberFormat("@");
    sh.appendRow(SHEETS[name]);
    sh.setFrozenRows(1);
  }
  return sh;
}
function rows_(sh) {
  const n = sh.getLastRow() - 1;
  return n > 0 ? sh.getRange(2, 1, n, SHEETS[sh.getName()].length).getValues() : [];
}
function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
function day_(ts) { return Utilities.formatDate(new Date(Number(ts)), TZ, "yyyy-MM-dd"); }

function doGet(e) {
  if ((e.parameter.pin || "") !== PIN) return json_({ error: "pin" });
  const students = rows_(sheet_("Students")).map(r => ({ id: String(r[0]), name: String(r[1]), roll: String(r[2]), house: String(r[3]) }));
  const logs = rows_(sheet_("Logs")).map(r => ({ id: String(r[0]), ts: Number(r[1]), sid: String(r[2]), kind: String(r[3]), det: String(r[4]) }));
  return json_({ students: students, logs: logs });
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const b = JSON.parse(e.postData.contents);
    if (b.pin !== PIN) return json_({ error: "pin" });
    const sS = sheet_("Students"), sL = sheet_("Logs");
    const people = {};
    rows_(sS).forEach(r => { people[String(r[0])] = { name: r[1], roll: r[2], house: r[3] }; });
    const logIds = {}, logKeys = {};
    rows_(sL).forEach(r => {
      logIds[String(r[0])] = 1;
      logKeys[[r[2], r[3], r[4], day_(r[1])].join("|")] = 1;
    });
    (b.ops || []).forEach(op => {
      if (op.t === "addStudent") {
        if (!people[op.id]) {
          sS.appendRow([op.id, op.name, op.roll, op.house]);
          people[op.id] = { name: op.name, roll: op.roll, house: op.house };
        }
      } else if (op.t === "delStudent") {
        const ids = sS.getLastRow() > 1 ? sS.getRange(2, 1, sS.getLastRow() - 1, 1).getValues() : [];
        for (let i = 0; i < ids.length; i++) {
          if (String(ids[i][0]) === String(op.id)) { sS.deleteRow(i + 2); break; }
        }
        delete people[op.id];
      } else if (op.t === "addLog") {
        const key = [op.sid, op.kind, op.det, day_(op.ts)].join("|");
        if (logIds[op.id] || (op.kind === "Mess" && logKeys[key])) return;
        const p = people[op.sid] || { name: "", roll: "", house: "" };
        const d = new Date(Number(op.ts));
        sL.appendRow([op.id, op.ts, op.sid, op.kind, op.det,
          Utilities.formatDate(d, TZ, "yyyy-MM-dd"), Utilities.formatDate(d, TZ, "HH:mm"),
          p.name, p.roll, p.house]);
        logIds[op.id] = 1; logKeys[key] = 1;
      } else if (op.t === "clearAll") {
        [sS, sL].forEach(sh => { const n = sh.getLastRow() - 1; if (n > 0) sh.deleteRows(2, n); });
        Object.keys(people).forEach(k => delete people[k]);
        Object.keys(logIds).forEach(k => delete logIds[k]);
        Object.keys(logKeys).forEach(k => delete logKeys[k]);
      }
    });
    return json_({ ok: true });
  } finally {
    lock.releaseLock();
  }
}
