// Paste your Google Apps Script Web app URL (ends with /exec) between the quotes.
window.JNV_CONFIG = { url: "" };
